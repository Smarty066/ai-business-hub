import { useState, useCallback, useEffect } from "react";

const STORAGE_KEY = "freemium_usage_v2";
const DAILY_LIMIT = 1;

interface UsageData {
  count: number;
  lastDate: string; // "YYYY-MM-DD"
}

function getCurrentDate(): string {
  return new Date().toISOString().split('T')[0];
}

function getUsageData(): UsageData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed: UsageData = JSON.parse(raw);
      // Reset if a new day
      if (parsed.lastDate !== getCurrentDate()) {
        return { count: 0, lastDate: getCurrentDate() };
      }
      return parsed;
    }
  } catch {
    // ignore parse errors
  }
  return { count: 0, lastDate: getCurrentDate() };
}

function saveUsageData(data: UsageData) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

export function useFreemiumGate() {
  const [usage, setUsage] = useState<UsageData>(getUsageData);
  const [showUpgrade, setShowUpgrade] = useState(false);

  // Sync from storage on mount / focus
  useEffect(() => {
    const sync = () => setUsage(getUsageData());
    window.addEventListener("focus", sync);
    return () => window.removeEventListener("focus", sync);
  }, []);

  const remaining = Math.max(0, DAILY_LIMIT - usage.count);
  const isLimitReached = usage.count >= DAILY_LIMIT;

  const tryConsume = useCallback((): boolean => {
    const current = getUsageData();
    if (current.count >= DAILY_LIMIT) {
      setShowUpgrade(true);
      return false;
    }
    const updated = { count: current.count + 1, lastDate: getCurrentDate() };
    saveUsageData(updated);
    setUsage(updated);
    return true;
  }, []);

  const closeUpgrade = useCallback(() => setShowUpgrade(false), []);
  const openUpgrade = useCallback(() => setShowUpgrade(true), []);

  return {
    used: usage.count,
    remaining,
    limit: DAILY_LIMIT,
    isLimitReached,
    showUpgrade,
    closeUpgrade,
    openUpgrade,
    tryConsume,
  };
}
