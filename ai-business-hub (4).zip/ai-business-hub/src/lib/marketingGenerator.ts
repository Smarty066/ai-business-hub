export interface GeneratedContent {
  whatsapp: { title: string; message: string }[];
}

export interface MarketingFormData {
  productName: string;
  description: string;
  audience: string;
  tone: string;
  goal: string;
}

const toneMap: Record<string, { adj: string; verb: string; cta: string }> = {
  professional: { adj: "Transform", verb: "Elevate", cta: "Get Started Today" },
  casual: { adj: "Level Up", verb: "Try Out", cta: "Jump In – It's Free!" },
  friendly: { adj: "Discover", verb: "Explore", cta: "Come See What's New!" },
  urgent: { adj: "Act Now –", verb: "Don't Wait –", cta: "Claim Your Spot Before It's Gone!" },
};

export function generateContent(data: MarketingFormData): GeneratedContent {
  const { productName, description, audience, tone } = data;
  const name = productName || "Your Product";
  const desc = description || "an innovative solution";
  const aud = audience || "your target audience";

  const t = toneMap[tone] || toneMap.professional;

  return {
    whatsapp: [
      {
        title: "Daily WhatsApp Content",
        message: `Hi there! 👋\n\n${t.adj} your business with ${name}.\n\nWe help ${aud} with ${desc}.\n\nReady to ${t.verb.toLowerCase()} your results? ${t.cta} 😊`,
      },
    ],
  };
}
