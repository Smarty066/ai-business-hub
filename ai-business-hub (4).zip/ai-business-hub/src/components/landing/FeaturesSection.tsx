import { Megaphone, Calendar, Wallet, CalendarDays, Users, ArrowRight, Package, TrendingUp, FileText, RefreshCw, Calculator } from "lucide-react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useScrollReveal } from "@/hooks/useScrollReveal";

const features = [
  {
    title: "WhatsApp Funnel Generator",
    description:
      "Generate high-converting WhatsApp marketing messages. Includes a daily generation limit and Nigerian-market specialized templates.",
    icon: Megaphone,
    href: "/marketing",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    title: "Smart Booking System",
    description:
      "Create public booking pages and manage appointments. Perfect for salons, consultants, and service businesses.",
    icon: Calendar,
    href: "/booking",
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    title: "Customer Management (CRM)",
    description:
      "Track your leads, manage customer details, and never miss a follow-up. Build lasting business relationships.",
    icon: Users,
    href: "/customers",
    color: "text-destructive",
    bgColor: "bg-destructive/10",
  },
  {
    title: "Financial Tracking",
    description:
      "Monitor your business budget, income, and expenses. Get a clear picture of your profitability anytime.",
    icon: Wallet,
    href: "/budget",
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
  {
    title: "Inventory Management",
    description:
      "Track stock levels, set reorder alerts, and generate branded inventory reports to share with partners.",
    icon: Package,
    href: "/inventory",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    title: "AI Sales Reports",
    description:
      "Generate daily, weekly, or monthly reports with one click. Professional PDF exports with your business name.",
    icon: TrendingUp,
    href: "/reports",
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    title: "Business Notes",
    description:
      "Securely store and search through important business ideas and categories. Smart tagging for quick access.",
    icon: FileText,
    href: "/notes",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    title: "Pricing & Converter",
    description:
      "Calculate optimal product prices and convert currencies instantly to stay competitive in the market.",
    icon: RefreshCw,
    href: "/pricing",
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    title: "Business Calculator",
    description:
      "Built-in calculator for quick business mathematics. Handle transactions and totals without leaving the app.",
    icon: Calculator,
    href: "/calculator",
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
];

function FeatureCard({ feature, index }: { feature: typeof features[number]; index: number }) {
  const { ref, isVisible } = useScrollReveal({ threshold: 0.1 });

  return (
    <div
      ref={ref}
      className={cn("scroll-reveal", isVisible && "revealed")}
      style={{ transitionDelay: `${index * 50}ms` }}
    >
      <Card
        className={cn(
          "group relative overflow-hidden glass-strong border-0 hover:scale-[1.02] hover:glow-sm transition-all duration-300 h-full"
        )}
      >
        <div className="absolute inset-0 gradient-card opacity-40" />
        <CardHeader className="relative p-5">
          <div
            className={cn(
              "w-10 h-10 rounded-lg flex items-center justify-center mb-3",
              feature.bgColor
            )}
          >
            <feature.icon className={cn("h-5 w-5", feature.color)} />
          </div>
          <CardTitle className="text-lg font-bold">{feature.title}</CardTitle>
          <CardDescription className="text-sm text-muted-foreground/90 leading-snug">
            {feature.description}
          </CardDescription>
        </CardHeader>
        <CardContent className="relative p-5 pt-0">
          <Button variant="ghost" className="group/btn p-0 h-auto" asChild>
            <Link to={feature.href}>
              <span className="text-primary text-sm font-bold">Try it now</span>
              <ArrowRight className="ml-1.5 h-3.5 w-3.5 text-primary transition-transform group-hover/btn:translate-x-1" />
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

export function FeaturesSection() {
  const { ref: headerRef, isVisible: headerVisible } = useScrollReveal();

  return (
    <section id="features" className="py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div
          ref={headerRef}
          className={cn("text-center mb-10 scroll-reveal", headerVisible && "revealed")}
        >
          <p className="text-sm font-bold text-primary uppercase tracking-[0.2em] mb-3">
            Everything in One Place
          </p>
          <h2 className="text-3xl sm:text-4xl font-black mb-4 leading-tight">
            Stop Juggling. <span className="text-gradient">Start Growing.</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed font-medium text-balance">
            Forget about using 5 different notebooks. OjaLink brings your customers, stock, and money together so you can see your business clearly.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard key={feature.title} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
