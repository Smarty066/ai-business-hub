import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "react-router-dom";

interface AuthDialogProps {
  children: React.ReactNode;
  defaultTab?: "login" | "register";
}

export function AuthDialog({ children, defaultTab = "login" }: AuthDialogProps) {
  const [, setLocation] = useState(window.location.pathname);
  const [open, setOpen] = useState(false);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    const businessNameInput = (document.getElementById('reg-business') as HTMLInputElement)?.value;
    if (businessNameInput) {
      localStorage.setItem('businessName', businessNameInput);
    }
    // User requested mock auth for now
    setOpen(false);
    window.location.href = "/dashboard";
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[400px]">
        <Tabs defaultValue={defaultTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Register</TabsTrigger>
          </TabsList>
          
          <TabsContent value="login">
            <DialogHeader className="pt-4 pb-2">
              <DialogTitle>Welcome Back</DialogTitle>
              <DialogDescription>
                Enter your credentials to access your dashboard.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAuth} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="login-email">Email</Label>
                <Input id="login-email" type="email" placeholder="name@email.com" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="login-password">Password</Label>
                <Input id="login-password" type="password" required />
              </div>
              <Button type="submit" className="w-full">Login</Button>
            </form>
          </TabsContent>

          <TabsContent value="register">
            <DialogHeader className="pt-4 pb-2">
              <DialogTitle>Create Account</DialogTitle>
              <DialogDescription>
                Join 2,400+ businesses working smarter.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAuth} className="space-y-4 pt-4">
                            <div className="space-y-2">
                  <Label htmlFor="reg-business">Business Name</Label>
                  <Input id="reg-business" placeholder="e.g. OjaLink Stores" required />
                </div>
              <div className="space-y-2">
                <Label htmlFor="reg-name">Full Name</Label>
                <Input id="reg-name" placeholder="John Doe" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-email">Email</Label>
                <Input id="reg-email" type="email" placeholder="name@email.com" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-phone">Phone Number</Label>
                <Input id="reg-phone" type="tel" placeholder="e.g. 08012345678" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reg-password">Password</Label>
                <Input id="reg-password" type="password" required />
              </div>
              <Button type="submit" className="w-full">Register</Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
