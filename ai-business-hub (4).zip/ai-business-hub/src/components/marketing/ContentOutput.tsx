import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Copy,
  Download,
  FileText,
  Megaphone,
  Mail,
  Layout,
  MessageCircle,
  Share2,
  Sparkles,
} from "lucide-react";
import { toast } from "sonner";
import { exportMarketingPdf } from "@/lib/exportPdf";
import type { GeneratedContent } from "@/lib/marketingGenerator";

interface ContentOutputProps {
  content: GeneratedContent | null;
  productName: string;
}

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text);
  toast.success("Copied to clipboard!");
}

export function ContentOutput({ content, productName }: ContentOutputProps) {
  if (!content) {
    return (
      <Card className="lg:col-span-3 glass-strong border-0">
        <CardHeader>
          <CardTitle className="text-lg">Generated Content</CardTitle>
          <CardDescription>Your AI-generated marketing materials</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
              <Sparkles className="h-8 w-8 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">No content generated yet</h3>
            <p className="text-sm text-muted-foreground max-w-sm">
              Fill in the product details and click "Generate Content" to create AI-powered marketing materials.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="lg:col-span-3 glass-strong border-0">
      <CardHeader>
        <CardTitle className="text-lg">Generated Content</CardTitle>
        <CardDescription>Your AI-generated marketing materials</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2 p-3 rounded-lg bg-success/10 border border-success/20">
            <MessageCircle className="h-5 w-5 text-success" />
            <p className="text-sm text-success">Ready to copy & paste into WhatsApp Business</p>
          </div>
          {content.whatsapp.map((msg, index) => (
            <div key={index} className="p-4 rounded-lg bg-secondary/50">
              <div className="flex items-center justify-between mb-2">
                <Badge variant="outline" className="bg-success/10 text-success border-success/30">
                  {msg.title}
                </Badge>
                <Button variant="ghost" size="icon" onClick={() => copyToClipboard(msg.message)}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-sm whitespace-pre-line leading-relaxed">{msg.message}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
