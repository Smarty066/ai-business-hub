import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { CurrencyProvider } from "@/hooks/useCurrency";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import Marketing from "./pages/Marketing";
import Booking from "./pages/Booking";
import Budget from "./pages/Budget";
import Customers from "./pages/Customers";
import Inventory from "./pages/Inventory";
import Pricing from "./pages/Pricing";
import CurrencyConverter from "./pages/CurrencyConverter";
import Calculator from "./pages/Calculator";
import Settings from "./pages/Settings";
import Affiliate from "./pages/affiliate/AffiliatePage";
import Notes from "./pages/notes/NotesPage";
import AdminDashboard from "./pages/admin/AdminDashboard";
import SalesReports from "./pages/reports/SalesReports";
import NotFound from "./pages/NotFound";
import PublicBooking from "./pages/PublicBooking";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <CurrencyProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/book" element={<PublicBooking />} />
            <Route element={<DashboardLayout />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/marketing" element={<Marketing />} />
              <Route path="/booking" element={<Booking />} />
              <Route path="/budget" element={<Budget />} />
              <Route path="/customers" element={<Customers />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/converter" element={<CurrencyConverter />} />
              <Route path="/calculator" element={<Calculator />} />
              <Route path="/affiliate" element={<Affiliate />} />
              <Route path="/notes" element={<Notes />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/reports" element={<SalesReports />} />
              <Route path="/settings" element={<Settings />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </CurrencyProvider>
  </QueryClientProvider>
);

export default App;
