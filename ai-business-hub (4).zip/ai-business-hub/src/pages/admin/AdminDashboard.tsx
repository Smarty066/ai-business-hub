import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Users, 
  CreditCard, 
  Search, 
  TrendingUp, 
  UserCheck, 
  ShieldCheck, 
  Mail, 
  Phone
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Mock data for members
const MOCK_MEMBERS = [
  { id: 1, name: "John Doe", email: "john@example.com", phone: "08012345678", plan: "Premium", joined: "2026-02-15", status: "Active" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", phone: "08198765432", plan: "Free", joined: "2026-02-18", status: "Active" },
  { id: 3, name: "Faruq Abiola", email: "faruqabiola629@gmail.com", phone: "09011223344", plan: "Premium", joined: "2026-01-01", status: "Active" },
  { id: 4, name: "Ade Wale", email: "ade@example.com", phone: "07055667788", plan: "Premium", joined: "2026-02-20", status: "Pending" },
  { id: 5, name: "Musa Bello", email: "musa@example.com", phone: "08033445566", plan: "Free", joined: "2026-02-22", status: "Active" },
];

export default function AdminDashboard() {
  const [search, setSearch] = useState("");

  const filteredMembers = MOCK_MEMBERS.filter(member => 
    member.name.toLowerCase().includes(search.toLowerCase()) ||
    member.email.toLowerCase().includes(search.toLowerCase()) ||
    member.phone.includes(search)
  );

  const stats = {
    totalMembers: MOCK_MEMBERS.length,
    premiumSubscribers: MOCK_MEMBERS.filter(m => m.plan === "Premium").length,
    activeToday: 3,
    revenue: "₦7,500"
  };

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <ShieldCheck className="h-8 w-8 text-primary" />
            Admin Control Center
          </h1>
          <p className="text-muted-foreground">Monitoring registered members and business growth</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Members</CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalMembers}</div>
            <p className="text-xs text-muted-foreground">+2 from yesterday</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Premium Subs</CardTitle>
            <CreditCard className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.premiumSubscribers}</div>
            <p className="text-xs text-muted-foreground">60% conversion rate</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Today</CardTitle>
            <UserCheck className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeToday}</div>
            <p className="text-xs text-muted-foreground">Current sessions</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.revenue}</div>
            <p className="text-xs text-muted-foreground">Target: ₦50k</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <CardTitle>Member Directory</CardTitle>
            <div className="relative w-full md:w-72">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search email, name or phone..." 
                className="pl-10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Member</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Joined</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMembers.map((member) => (
                  <TableRow key={member.id}>
                    <TableCell className="font-medium">{member.name}</TableCell>
                    <TableCell>
                      <div className="flex flex-col text-xs gap-1">
                        <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> {member.email}</span>
                        <span className="flex items-center gap-1 text-muted-foreground"><Phone className="h-3 w-3" /> {member.phone}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={member.plan === 'Premium' ? 'hero' : 'outline'}>
                        {member.plan}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{member.joined}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className={member.status === 'Active' ? "h-2 w-2 rounded-full bg-green-500" : "h-2 w-2 rounded-full bg-yellow-500"} />
                        {member.status}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
