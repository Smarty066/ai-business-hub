import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  StickyNote, 
  Plus, 
  Search, 
  Tag as TagIcon, 
  Clock, 
  Trash2, 
  Save,
  SearchCode,
  Zap,
  Briefcase
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Note {
  id: string;
  title: string;
  content: string;
  tags: string[];
  updatedAt: Date;
  category: 'business' | 'personal' | 'important';
}

export default function NotesPage() {
  const [notes, setNotes] = useState<Note[]>([
    {
      id: "1",
      title: "Supplier Meeting - March",
      content: "Discussed bulk discount for the new fabric batch. Need to follow up on Friday about delivery timelines.",
      tags: ["supplier", "inventory"],
      updatedAt: new Date(),
      category: 'business'
    },
    {
      id: "2",
      title: "New Marketing Idea",
      content: "Use WhatsApp Status for flash sales every Tuesday at 10 AM.",
      tags: ["marketing", "whatsapp"],
      updatedAt: new Date(Date.now() - 86400000),
      category: 'important'
    }
  ]);

  const [search, setSearch] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [newNote, setNewNote] = useState<{ title: string; content: string; category: 'business' | 'important' }>({ 
    title: "", 
    content: "", 
    category: 'business' 
  });

  const filteredNotes = useMemo(() => {
    return notes.filter(note => 
      note.title.toLowerCase().includes(search.toLowerCase()) ||
      note.content.toLowerCase().includes(search.toLowerCase()) ||
      note.tags.some(tag => tag.toLowerCase().includes(search.toLowerCase()))
    ).sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }, [notes, search]);

  const handleAddNote = () => {
    if (!newNote.title || !newNote.content) {
      toast.error("Please fill in both title and content");
      return;
    }

    const note: Note = {
      id: Date.now().toString(),
      title: newNote.title,
      content: newNote.content,
      tags: [],
      updatedAt: new Date(),
      category: newNote.category
    };

    setNotes([note, ...notes]);
    setNewNote({ title: "", content: "", category: 'business' });
    setIsAdding(false);
    toast.success("Note saved successfully!");
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter(n => n.id !== id));
    toast.success("Note deleted");
  };

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <StickyNote className="h-8 w-8 text-primary" />
            Business Notes
          </h1>
          <p className="text-muted-foreground">Capture ideas and important business details instantly</p>
        </div>
        <Button onClick={() => setIsAdding(!isAdding)} className="gap-2">
          {isAdding ? "Cancel" : <><Plus className="h-4 w-4" /> New Note</>}
        </Button>
      </div>

      {/* Innovation: Quick Search & Filter Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input 
          placeholder="Search by title, content, or keywords..." 
          className="pl-10 h-12 text-lg border-2 border-primary/10 focus:border-primary/40"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 hidden sm:flex items-center gap-2">
          <Badge variant="outline" className="bg-background/50">Smart Search Enabled</Badge>
          <SearchCode className="h-4 w-4 text-primary" />
        </div>
      </div>

      {isAdding && (
        <Card className="border-2 border-primary animate-in fade-in slide-in-from-top-4 duration-300">
          <CardHeader>
            <CardTitle>Create New Business Note</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input 
              placeholder="Note Title (e.g., Customer Feedback)" 
              value={newNote.title}
              onChange={(e) => setNewNote({...newNote, title: e.target.value})}
            />
            <div className="flex gap-2">
              <Button 
                variant={newNote.category === 'business' ? 'hero' : 'outline'} 
                type="button"
                size="sm"
                onClick={() => setNewNote(prev => ({...prev, category: 'business'}))}
              >
                <Briefcase className="h-4 w-4 mr-2" /> Business
              </Button>
              <Button 
                variant={newNote.category === 'important' ? 'hero' : 'outline'} 
                type="button"
                size="sm"
                onClick={() => setNewNote(prev => ({...prev, category: 'important'}))}
              >
                <Zap className="h-4 w-4 mr-2" /> Important
              </Button>
            </div>
            <Textarea 
              placeholder="Write down your thoughts here..." 
              className="min-h-[150px]"
              value={newNote.content}
              onChange={(e) => setNewNote({...newNote, content: e.target.value})}
            />
            <Button onClick={handleAddNote} className="w-full gap-2">
              <Save className="h-4 w-4" /> Save Note
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredNotes.map((note) => (
          <Card key={note.id} className="group hover:border-primary/50 transition-all duration-300 hover:shadow-lg">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-lg leading-none">{note.title}</CardTitle>
                    {note.category === 'important' && <Zap className="h-4 w-4 text-primary fill-primary" />}
                  </div>
                  <div className="flex items-center text-[10px] text-muted-foreground">
                    <Clock className="h-3 w-3 mr-1" />
                    {note.updatedAt.toLocaleDateString()}
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => deleteNote(note.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground line-clamp-4 mb-4 whitespace-pre-wrap">
                {note.content}
              </p>
              <div className="flex flex-wrap gap-1">
                {note.tags.map(tag => (
                  <Badge key={tag} variant="secondary" className="text-[10px] py-0 px-2">
                    #{tag}
                  </Badge>
                ))}
                {note.tags.length === 0 && (
                  <span className="text-[10px] text-muted-foreground flex items-center">
                    <TagIcon className="h-3 w-3 mr-1" /> No tags
                  </span>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredNotes.length === 0 && (
        <div className="text-center py-20">
          <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-muted mb-4">
            <Search className="h-10 w-10 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold">No notes found</h3>
          <p className="text-muted-foreground">Try adjusting your search or create a new note</p>
        </div>
      )}
    </div>
  );
}
