import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useCurrency } from "@/hooks/useCurrency";
import { 
  Users, 
  Wallet, 
  ArrowUpRight, 
  Copy, 
  CheckCircle2, 
  History,
  TrendingUp,
  Gift
} from "lucide-react";
import { toast } from "sonner";

export default function AffiliatePage() {
  const { currency, symbol, formatAmount } = useCurrency();
  const [copied, setCopied] = useState(false);

  // Constants based on user requirements
  const SIGNUP_BONUS_NGN = 1000;
  const SIGNUP_BONUS_USD = 0.5;
  const MONTHLY_COMMISSION_NGN = 250;
  const MIN_WITHDRAWAL_NGN = 1000;
  const SUBSCRIPTION_COST_NGN = 2500;

  // Mock data for UI
  const stats = {
    totalEarnings: currency === "NGN" ? 4500 : 2.25,
    pendingEarnings: currency === "NGN" ? 1250 : 0.62,
    totalReferrals: 12,
    activeSubscriptions: 5,
    referralCode: "OJALINK-USER-123",
  };

  const copyReferralLink = () => {
    const link = `https://ojalink.com/register?ref=${stats.referralCode}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    toast.success("Referral link copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  const currentEarnings = stats.totalEarnings;
  const canWithdraw = currency === "NGN" ? currentEarnings >= MIN_WITHDRAWAL_NGN : currentEarnings >= 0.5;
  const canSubscribe = currency === "NGN" ? currentEarnings >= SUBSCRIPTION_COST_NGN : currentEarnings >= 1.25;

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Affiliate Program</h1>
          <p className="text-muted-foreground">Invite friends and earn recurring rewards</p>
        </div>
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-2 bg-primary/10 rounded-full">
              <Wallet className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Available Balance</p>
              <p className="text-2xl font-bold text-primary">{formatAmount(stats.totalEarnings)}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Referral Link Section */}
      <Card className="border-2 border-primary/20 bg-gradient-to-br from-background to-primary/5">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex-1 space-y-2">
              <h3 className="text-xl font-semibold flex items-center gap-2">
                <Gift className="h-5 w-5 text-primary" />
                Your Referral Link
              </h3>
              <p className="text-muted-foreground">
                Share this link and earn {currency === "NGN" ? formatAmount(SIGNUP_BONUS_NGN) : formatAmount(SIGNUP_BONUS_USD)} for every new signup!
              </p>
              <div className="flex gap-2 pt-2">
                <div className="relative flex-1">
                  <Input 
                    readOnly 
                    value={`https://ojalink.com/register?ref=${stats.referralCode}`}
                    className="pr-10 bg-background/50"
                  />
                  <Button
                    size="icon"
                    variant="ghost"
                    className="absolute right-0 top-0 h-full"
                    onClick={copyReferralLink}
                  >
                    {copied ? <CheckCircle2 className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
                <Button onClick={copyReferralLink}>Copy Link</Button>
              </div>
            </div>
            <div className="hidden lg:block w-px h-24 bg-border" />
            <div className="grid grid-cols-2 gap-8 px-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-primary">{stats.totalReferrals}</p>
                <p className="text-sm text-muted-foreground">Total Referrals</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-primary">{stats.activeSubscriptions}</p>
                <p className="text-sm text-muted-foreground">Active Subs</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Earnings Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-success" />
              Earnings Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Signup Commissions</span>
              <span className="font-medium">{formatAmount(stats.totalReferrals * (currency === "NGN" ? SIGNUP_BONUS_NGN : SIGNUP_BONUS_USD))}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Recurring (Monthly)</span>
              <span className="font-medium text-success">+{formatAmount(stats.activeSubscriptions * (currency === "NGN" ? MONTHLY_COMMISSION_NGN : 0.12))}</span>
            </div>
            <div className="pt-4 border-t border-border">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-semibold">Withdrawal Progress</span>
                <span className="text-xs text-muted-foreground">
                  {formatAmount(currentEarnings)} / {formatAmount(currency === "NGN" ? MIN_WITHDRAWAL_NGN : 0.5)}
                </span>
              </div>
              <Progress value={Math.min((currentEarnings / (currency === "NGN" ? MIN_WITHDRAWAL_NGN : 0.5)) * 100, 100)} className="h-2" />
            </div>
            <div className="flex flex-col gap-2 pt-2">
              <Button disabled={!canWithdraw} className="w-full">
                Withdraw Earnings
              </Button>
              <Button disabled={!canSubscribe} variant="outline" className="w-full">
                Use for Subscription
              </Button>
              {!canWithdraw && (
                <p className="text-[10px] text-center text-muted-foreground italic">
                  Minimum withdrawal: {formatAmount(currency === "NGN" ? MIN_WITHDRAWAL_NGN : 0.5)}
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* How it works */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Commission Structure</CardTitle>
            <CardDescription>How you earn with OjaLink</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-lg border border-border bg-muted/30">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-primary/10 rounded-md">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <h4 className="font-semibold">Direct Referral</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Earn <span className="text-foreground font-bold">{formatAmount(currency === "NGN" ? SIGNUP_BONUS_NGN : SIGNUP_BONUS_USD)}</span> for every unique business that registers using your link.
                </p>
              </div>
              <div className="p-4 rounded-lg border border-border bg-muted/30">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-success/10 rounded-md">
                    <ArrowUpRight className="h-5 w-5 text-success" />
                  </div>
                  <h4 className="font-semibold">Monthly Recurring</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  Earn <span className="text-foreground font-bold">{formatAmount(currency === "NGN" ? MONTHLY_COMMISSION_NGN : 0.12)}</span> every month your referral maintains their <span className="text-foreground font-bold">{formatAmount(currency === "NGN" ? SUBSCRIPTION_COST_NGN : 1.25)}</span> subscription.
                </p>
              </div>
            </div>

            <div className="mt-6 p-4 rounded-lg bg-primary/5 border border-primary/10">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <History className="h-4 w-4" />
                Recent History
              </h4>
              <div className="space-y-3">
                {[
                  { label: "Referral Signup: Adebayo Store", date: "2 hours ago", amount: 1000, type: "plus" },
                  { label: "Monthly Commission: Grace Boutique", date: "Yesterday", amount: 250, type: "plus" },
                  { label: "Withdrawal to Bank", date: "3 days ago", amount: -2000, type: "minus" },
                ].map((item, i) => (
                  <div key={i} className="flex justify-between items-center text-sm">
                    <div>
                      <p className="font-medium">{item.label}</p>
                      <p className="text-xs text-muted-foreground">{item.date}</p>
                    </div>
                    <span className={item.type === "plus" ? "text-success font-bold" : "text-destructive font-bold"}>
                      {item.type === "plus" ? "+" : ""}{formatAmount(item.amount)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
