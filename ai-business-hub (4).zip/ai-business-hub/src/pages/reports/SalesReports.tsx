import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  BarChart3, 
  Download, 
  Share2, 
  TrendingUp, 
  Calendar as CalendarIcon,
  FileText,
  DollarSign,
  Package,
  ArrowUpRight
} from "lucide-react";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function SalesReports() {
  const businessName = localStorage.getItem('businessName') || 'OjaLink Business';

  const handleShare = async () => {
    const text = `${businessName} - Sales Report (${reportType})\nTotal Sales: ${currentReport.total}\nItems Sold: ${currentReport.items}\nTop Item: ${currentReport.breakdown[0].name}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Business Sales Report',
          text: text,
          url: window.location.href,
        });
      } catch (err) {
        toast.error("Sharing failed");
      }
    } else {
      navigator.clipboard.writeText(text);
      toast.success("Report summary copied to clipboard for sharing!");
    }
  };

  const handleDownloadPDF = () => {
    toast.info(`Generating PDF report for ${businessName}... Your download will start shortly.`);
  };

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BarChart3 className="h-8 w-8 text-primary" />
            AI Sales Reports
          </h1>
          <p className="text-muted-foreground">Automated business intelligence for your sales performance</p>
        </div>
        <div className="flex items-center gap-2">
          <Input 
            type="date" 
            value={selectedDate} 
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-[150px]"
          />
          <Select value={reportType} onValueChange={setReportType}>
            <SelectTrigger className="w-[150px]">
              <CalendarIcon className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily Report</SelectItem>
              <SelectItem value="weekly">Weekly Report</SelectItem>
              <SelectItem value="monthly">Monthly Report</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentReport.total}</div>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <TrendingUp className="h-3 w-3 text-green-500" />
              {currentReport.growth} from last period
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Items Sold</CardTitle>
            <Package className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentReport.items}</div>
            <p className="text-xs text-muted-foreground">Volume moved</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Top Performer</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold truncate">{currentReport.breakdown[0].name.split(' (')[0]}</div>
            <p className="text-xs text-muted-foreground">Highest contribution</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Sales Breakdown</CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleDownloadPDF} className="gap-2">
              <Download className="h-4 w-4" /> PDF
            </Button>
            <Button variant="hero" size="sm" onClick={handleShare} className="gap-2">
              <Share2 className="h-4 w-4" /> Share
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {currentReport.breakdown.map((item, i) => (
              <div key={i} className="flex items-center justify-between p-4 rounded-lg bg-muted/50 border">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Package className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">{item.name}</p>
                    <p className="text-xs text-muted-foreground">Unit Price: {item.unitPrice}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-primary">{item.value}</p>
                  <p className="text-[10px] text-muted-foreground flex items-center justify-end gap-1">
                    Confirmed <ArrowUpRight className="h-2 w-2" />
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col items-center justify-center p-8 bg-muted/30 rounded-2xl border-2 border-dashed border-muted">
        <FileText className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold">Generate Full Business Audit</h3>
        <p className="text-sm text-muted-foreground mb-6 text-center max-w-md">
          Need a more detailed report for tax or inventory purposes? Generate a full audit with one click.
        </p>
        <Button variant="outline" className="gap-2">
          <BarChart3 className="h-4 w-4" /> Prepare Full Audit
        </Button>
      </div>
    </div>
  );
}
