import { Megaphone, Lock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Marketing() {
  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto h-[calc(100vh-80px)] flex flex-col items-center justify-center">
      <Card className="max-w-md w-full glass-strong border-0 p-8 text-center relative overflow-hidden group">
        <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
        
        <div className="relative z-10">
          <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
            <Lock className="h-10 w-10 text-primary animate-pulse" />
          </div>
          
          <h1 className="text-3xl font-bold mb-3">WhatsApp Funnel</h1>
          <Badge className="bg-primary/20 text-primary mb-6">Encrypted & Secure</Badge>
          
          <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
            Our AI-powered WhatsApp Marketing engine is currently being optimized for high-conversion sales funnels.
          </p>
          
          <div className="p-4 rounded-xl bg-secondary/50 border border-border">
            <h2 className="text-xl font-bold text-gradient uppercase tracking-widest">Coming Soon</h2>
          </div>
        </div>
      </Card>
      
      <div className="mt-8 flex gap-4 text-sm text-muted-foreground/60 italic">
        <span>End-to-end encryption active</span>
        <span>•</span>
        <span>Premium feature</span>
      </div>
    </div>
  );
}
